// Organization is not empty
public class NotEmptyException extends Exception{  
    NotEmptyException(String s){  
        super(s);  
    }  
}
